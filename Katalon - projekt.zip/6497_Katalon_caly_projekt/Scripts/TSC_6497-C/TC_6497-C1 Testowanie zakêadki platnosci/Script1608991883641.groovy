import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys



//zalogowanie - dane wpisane z ręki - logowanie nie jest obiektem testowania w tym przypadku
WebUI.openBrowser('')

WebUI.navigateToUrl('https://demobank.jaktestowac.pl/logowanie_prod.html')

WebUI.setText(findTestObject('Object Repository/Page_Demobank - Strona gwna - Logowanie/input_identyfikator_login_id'), '11111111')

WebUI.click(findTestObject('Object Repository/Page_Demobank - Strona gwna - Logowanie/button_dalej'))

WebUI.setText(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Logowanie/input_haso_haslo'), '11112222')

WebUI.click(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Logowanie/button_zaloguj si'))


//zakladka platnosci
WebUI.click(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Pulpit/a_patnoci'))



//testowanie wykonywania przelewów
for (def rowNum = 1; rowNum <= findTestData('TS_6497-C zmienne/TS_6497-C-dane do platnosci').getRowNumbers(); rowNum++) {
	
	WebUI.setText(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Przelew/input_nazwa odbiorcy_form_receiver'), 
	    findTestData('TS_6497-C zmienne/TS_6497-C-dane do platnosci').getValue(2, rowNum))
	
	WebUI.setText(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Przelew/input_na rachunek_form_account_to'), 
	    findTestData('TS_6497-C zmienne/TS_6497-C-dane do platnosci').getValue(3, rowNum))
	
	WebUI.setText(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Przelew/input_kwota_form_amount'), 
	    findTestData('TS_6497-C zmienne/TS_6497-C-dane do platnosci').getValue(4, rowNum))
	
	WebUI.click(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Przelew/div_tytuem                                 _9fbe98'))
	
	WebUI.setText(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Przelew/textarea_przelew rodkw'), 
	    findTestData('TS_6497-C zmienne/TS_6497-C-dane do platnosci').getValue(5, rowNum))
	
	WebUI.click(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Przelew/span'))
	
	WebUI.setText(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Przelew/input_adres e-mail_form_email'), 
	    findTestData('TS_6497-C zmienne/TS_6497-C-dane do platnosci').getValue(6, rowNum))
	

	
	WebUI.click(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Przelew/button_dalej'))
}


WebUI.closeBrowser()




/*
WebUI.click(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Przelew/strong_12 659,20'))

WebUI.click(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Przelew/div_po przelewie                           _d7b057'))

WebUI.click(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Przelew/button_dalej'))



findTestData('TS_6497-B zmienne/TS_6497-B dane do szybkiego przelewu').getValue(1, rowNum)



if (WebUI.verifyElementNotPresent(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Pulpit/div_pole wymagane'), 5, FailureHandling.OPTIONAL)) {
	
	WebUI.click(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Pulpit/button_wykonaj'))
	KeywordUtil.markPassed('TEST B1 PASSED')
}
else if (WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Pulpit/div_pole wymagane'), 5, FailureHandling.OPTIONAL))
{
	KeywordUtil.markFailed("TEST B1 FAILED")
}
*/