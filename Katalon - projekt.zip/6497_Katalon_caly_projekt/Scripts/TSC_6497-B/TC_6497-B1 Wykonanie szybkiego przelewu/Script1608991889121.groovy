import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.junit.After
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.util.KeywordUtil


//zalogowanie - dane wpisane z ręki - logowanie nie jest obiektem testowania w tym przypadku
WebUI.openBrowser('')

WebUI.navigateToUrl('https://demobank.jaktestowac.pl/logowanie_etap_1.html?')

WebUI.setText(findTestObject('Object Repository/Page_Demobank - Strona gwna - Logowanie/input_identyfikator_login_id'), '11112222')

WebUI.click(findTestObject('Object Repository/Page_Demobank - Strona gwna - Logowanie/button_dalej'))

WebUI.setText(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Logowanie/input_haso_haslo'), '11112222')

WebUI.click(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Logowanie/button_zaloguj si'))

//testowanie wykonywania przelewów
for (def rowNum = 1; rowNum <= findTestData('TS_6497-B zmienne/TS_6497-B dane do szybkiego przelewu').getRowNumbers(); rowNum++) {
	
	WebUI.selectOptionByValue(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Pulpit/select_wybierz odbiorc przelewu            _029a71'),
	findTestData('TS_6497-B zmienne/TS_6497-B dane do szybkiego przelewu').getValue(1, rowNum), true)

	WebUI.click(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Pulpit/div_kwota                                  _7f3faa'))

	WebUI.setText(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Pulpit/input_kwota_widget_1_transfer_amount'),
		findTestData('TS_6497-B zmienne/TS_6497-B dane do szybkiego przelewu').getValue(2, rowNum))

	WebUI.click(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Pulpit/input_tytuem_widget_1_transfer_title'))

	WebUI.setText(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Pulpit/input_tytuem_widget_1_transfer_title'),
		findTestData('TS_6497-B zmienne/TS_6497-B dane do szybkiego przelewu').getValue(3, rowNum))

	//kliknięcie na boku w celu usunięcia error popup
	WebUI.click(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Pulpit/div_wykonaj'))
	
	
    if (WebUI.verifyElementNotPresent(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Pulpit/div_pole wymagane'), 5, FailureHandling.OPTIONAL)) {
		
		WebUI.click(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Pulpit/button_wykonaj'))
		KeywordUtil.markPassed('TEST B1 PASSED')
    }
	else if (WebUI.verifyElementPresent(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Pulpit/div_pole wymagane'), 5, FailureHandling.OPTIONAL))
	{
		KeywordUtil.markFailed("TEST B1 FAILED")
	}
    

	
}


WebUI.closeBrowser()




