import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.testobject.ConditionType



WebUI.openBrowser('')

WebUI.navigateToUrl(findTestData("TS_6497-A zmienne/TS_6497-A strony").getValue(1,1))



for(def rowNum=1; rowNum<=findTestData('TS_6497-A zmienne/TS_6497-A dane uzytkownikow').getRowNumbers(); rowNum++){

	WebUI.setText(findTestObject('Object Repository/Page_Demobank - Strona gwna - Logowanie/input_identyfikator_login_id'),
		findTestData('TS_6497-A zmienne/TS_6497-A dane uzytkownikow').getValue(1, rowNum))
	
	Thread.sleep(500)
	
	if(WebUI.verifyElementNotHasAttribute(findTestObject('Object Repository/Page_Demobank - Strona gwna - Logowanie/button_dalej'), 'disabled', 5))
	{
		WebUI.click(findTestObject('Object Repository/Page_Demobank - Strona gwna - Logowanie/button_dalej'))
	}
	else
	{
		KeywordUtil.markFailed("TEST A-2 FAILED 1")	
		//NIE DZIALA Z UWAGI NA BUG W KATALONIE - PROBLEMY Z TIMEOUTEM
	}
	
	
	
	WebUI.setText(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Logowanie/input_haso_haslo'),
		findTestData('TS_6497-A zmienne/TS_6497-A dane uzytkownikow').getValue(2, rowNum))
	
	
	
	
	if(WebUI.verifyElementNotHasAttribute(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Logowanie/button_zaloguj si'), 'disabled', 5))
	{
		WebUI.click(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Logowanie/button_zaloguj si'))
		
		Thread.sleep(1000)
		WebUI.click(findTestObject('Object Repository/Page_Demobank - Bankowo Internetowa - Pulpit/a_Wyloguj'))
		
		KeywordUtil.markPassed("TEST A-2 PASSED")
		
	}
	else
	{		
		KeywordUtil.markFailed("TEST A-2 FAILED 2")
	}

	
} 

WebUI.closeBrowser()









