
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String



def static "com.kms.katalon.keyword.testlink.TestlinkKeywords.updateResults"(
    	String testcaseName	
     , 	String exception	
     , 	String results	) {
    (new com.kms.katalon.keyword.testlink.TestlinkKeywords()).updateResults(
        	testcaseName
         , 	exception
         , 	results)
}
