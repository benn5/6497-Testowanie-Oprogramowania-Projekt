<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Konto na ycie                          _1c51cc</name>
   <tag></tag>
   <elementGuidId>969c5825-a8b9-49c2-ac29-0a35e6608509</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='accounts_list']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#accounts_list</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dashboard-list</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>accounts_list</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                
                                    
                                        
                                            
                                                Konto na życie

                                                

                                                (41 4100 1111 1111 1111 1111 0000)
                                            

                                            
                                                
                                                    dostępne
                                                        środki

                                                    
                                                        dostępne środki

                                                        
                                                            13 159

                                                            ,20

                                                            PLN
                                                        
                                                    
                                                
                                            

                                            
                                                wykonaj
                                                    przelew
                                            
                                        

                                        
                                            
                                                
                                                    saldo

                                                    
                                                        
                                                            3 159

                                                            ,20

                                                            PLN
                                                        
                                                    
                                                

                                                
                                                    blokady
                                                        na koncie

                                                    
                                                        
                                                            300

                                                            ,00

                                                            PLN
                                                        
                                                    

                                                    
                                                        szczegóły
                                                    
                                                

                                                
                                                    limit
                                                        kredytowy do wykorzystania

                                                    
                                                        
                                                            10 000

                                                            ,00

                                                            PLN
                                                        
                                                    
                                                

                                                
                                                    posiadacz

                                                    Jan
                                                        Demobankowy
                                                
                                            

                                            
                                                historia konta
                                                szczegóły konta
                                                manager finansowy
                                            
                                        
                                    

                                    
                                        
                                            
                                                szybki przelew

                                                
                                                    
                                                        widżet umożliwia zlecenie przelewu zwykłego do jednego ze
                                                        zdefiniowanych odbiorców
                                                    
                                                

                                                
                                                    
                                                        do

                                                        
                                                            wybierz odbiorcę przelewu
                                                                wybierz odbiorcę przelewu

                                                                
                                                                    Jan Demobankowy
                                                                

                                                                
                                                                    Chuck Demobankowy
                                                                
                                                            
                                                        
                                                    

                                                    
                                                        kwota

                                                        
                                                            
                                                        

                                                        PLN
                                                    

                                                    
                                                        tytułem

                                                        
                                                            
                                                        
                                                    

                                                    
                                                        
                                                            wykonaj
                                                        
                                                    
                                                
                                            
                                        

                                        
                                            
                                                ostatnie operacje

                                                
                                                    
                                                        
                                                            07.11.13

                                                            
                                                                
                                                            

                                                            
                                                                
                                                                    PayU S.A.,
                                                                    Płatność
                                                                    onlineID:123456 PayU w Allegro
                                                                

                                                                7.11.13
                                                            

                                                            
                                                                
                                                                    -341

                                                                    
                                                                        ,70

                                                                        PLN
                                                                    
                                                                
                                                            
                                                        

                                                        
                                                            05.11.15

                                                            
                                                                
                                                            

                                                            
                                                                
                                                                    Odsetki -
                                                                    Kapitalizacja
                                                                    odsetek
                                                                

                                                                05.10.15
                                                            

                                                            
                                                                
                                                                    1

                                                                    
                                                                        ,33

                                                                        PLN
                                                                    
                                                                
                                                            
                                                        

                                                        
                                                            22.10.13

                                                            
                                                                
                                                            

                                                            
                                                                
                                                                    Katowice, Zakup
                                                                    towarow i uslug karta
                                                                

                                                                05.10.15
                                                            

                                                            
                                                                
                                                                    -187

                                                                    
                                                                        ,68

                                                                        PLN
                                                                    
                                                                
                                                            
                                                        
                                                    
                                                

                                                
                                                    
                                                        przejdź
                                                        do historii
                                                    
                                                
                                            
                                        

                                        
                                            
                                                doładowanie telefonu

                                                
                                                    
                                                        do

                                                        
                                                            
                                                                    500
                                                                    xxx xxx
                                                                
                                                                
                                                                    wybierz telefon do doładowania
                                                                

                                                                
                                                                    500
                                                                    xxx xxx
                                                                

                                                                
                                                                    501
                                                                    xxx xxx
                                                                
                                                            
                                                        
                                                    

                                                    
                                                        kwota

                                                        
                                                            
                                                        

                                                        PLN

                                                        
                                                            
                                                                
                                                                    Informacje o doładowaniu:

                                                                    
                                                                    Minimalna kwota
                                                                    doładowania
                                                                    to:

                                                                    5
                                                                    zł

                                                                    
                                                                    Maksymalna
                                                                    kwota doładowania to:

                                                                    150
                                                                    zł
                                                                
                                                            
                                                        
                                                    

                                                    
                                                        
                                                            

                                                            zapoznałem
                                                            się z

                                                            
                                                                regulaminem
                                                                doładowania on-line
                                                            

                                                            i akceptuję warunki
                                                        
                                                    

                                                    
                                                        
                                                            doładuj telefon
                                                        
                                                    
                                                
                                            
                                        

                                        
                                            
                                                manager finansowy

                                                
                                                    
                                                        wpływy
                                                        i wydatki za okres
                                                    

                                                    
                                                        ostatnie 3 miesiące
                                                            bieżący miesiąc

                                                            poprzedni miesiąc

                                                            ostatnie 3 miesiące

                                                            ostatnie 6 miesięcy

                                                            bieżący rok

                                                            poprzedni rok
                                                        
                                                    

                                                    -4 000 PLN-2 000 PLN0 PLN2 000 PLN4 000 PLN6 000 PLNShow all
                                                
                                            
                                        
                                    
                                
                            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;accounts_list&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='accounts_list']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='main_content']/section/div[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/section/div[2]</value>
   </webElementXpaths>
</WebElementEntity>
