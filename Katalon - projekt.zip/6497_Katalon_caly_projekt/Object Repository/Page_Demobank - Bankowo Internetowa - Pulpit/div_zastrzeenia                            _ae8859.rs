<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_zastrzeenia                            _ae8859</name>
   <tag></tag>
   <elementGuidId>2a81edc7-393b-4630-9414-9a8888caef4b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.main-content.dashboard</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>main-content dashboard</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    
                        
                            
                                
                                        
                                            
                                            zastrzeżenia
                                        
                                    
                                    
                                        
                                            
                                            mój pulpit
                                        
                                    

                                    
                                        
                                            
                                            kalendarz
                                        
                                    

                                    
                                
                            
                        
                    

                    
                        
                            
                                
                                    zarządzaj
                                    pulpitem
                                

                                
                                    wykonaj
                                    przelew
                                
                            

                            
                                
                                konta osobiste
                            

                            
                                
                                    
                                        
                                            
                                                Konto na życie

                                                

                                                (41 4100 1111 1111 1111 1111 0000)
                                            

                                            
                                                
                                                    dostępne
                                                        środki

                                                    
                                                        dostępne środki

                                                        
                                                            13 159

                                                            ,20

                                                            PLN
                                                        
                                                    
                                                
                                            

                                            
                                                wykonaj
                                                    przelew
                                            
                                        

                                        
                                            
                                                
                                                    saldo

                                                    
                                                        
                                                            3 159

                                                            ,20

                                                            PLN
                                                        
                                                    
                                                

                                                
                                                    blokady
                                                        na koncie

                                                    
                                                        
                                                            300

                                                            ,00

                                                            PLN
                                                        
                                                    

                                                    
                                                        szczegóły
                                                    
                                                

                                                
                                                    limit
                                                        kredytowy do wykorzystania

                                                    
                                                        
                                                            10 000

                                                            ,00

                                                            PLN
                                                        
                                                    
                                                

                                                
                                                    posiadacz

                                                    Jan
                                                        Demobankowy
                                                
                                            

                                            
                                                historia konta
                                                szczegóły konta
                                                manager finansowy
                                            
                                        
                                    

                                    
                                        
                                            
                                                szybki przelew

                                                
                                                    
                                                        widżet umożliwia zlecenie przelewu zwykłego do jednego ze
                                                        zdefiniowanych odbiorców
                                                    
                                                

                                                
                                                    
                                                        do

                                                        
                                                            
                                                                    Jan Demobankowy
                                                                
                                                                wybierz odbiorcę przelewu

                                                                
                                                                    Jan Demobankowy
                                                                

                                                                
                                                                    Chuck Demobankowy
                                                                
                                                            
                                                        
                                                    

                                                    
                                                        kwota

                                                        
                                                            
                                                        

                                                        PLN
                                                    

                                                    
                                                        tytułem

                                                        
                                                            
                                                        
                                                    

                                                    
                                                        
                                                            wykonaj
                                                        
                                                    
                                                
                                            
                                        

                                        
                                            
                                                ostatnie operacje

                                                
                                                    
                                                        
                                                            07.11.13

                                                            
                                                                
                                                            

                                                            
                                                                
                                                                    PayU S.A.,
                                                                    Płatność
                                                                    onlineID:123456 PayU w Allegro
                                                                

                                                                7.11.13
                                                            

                                                            
                                                                
                                                                    -341

                                                                    
                                                                        ,70

                                                                        PLN
                                                                    
                                                                
                                                            
                                                        

                                                        
                                                            05.11.15

                                                            
                                                                
                                                            

                                                            
                                                                
                                                                    Odsetki -
                                                                    Kapitalizacja
                                                                    odsetek
                                                                

                                                                05.10.15
                                                            

                                                            
                                                                
                                                                    1

                                                                    
                                                                        ,33

                                                                        PLN
                                                                    
                                                                
                                                            
                                                        

                                                        
                                                            22.10.13

                                                            
                                                                
                                                            

                                                            
                                                                
                                                                    Katowice, Zakup
                                                                    towarow i uslug karta
                                                                

                                                                05.10.15
                                                            

                                                            
                                                                
                                                                    -187

                                                                    
                                                                        ,68

                                                                        PLN
                                                                    
                                                                
                                                            
                                                        
                                                    
                                                

                                                
                                                    
                                                        przejdź
                                                        do historii
                                                    
                                                
                                            
                                        

                                        
                                            
                                                doładowanie telefonu

                                                
                                                    
                                                        do

                                                        
                                                            
                                                                    wybierz telefon do doładowania
                                                                
                                                                
                                                                    wybierz telefon do doładowania
                                                                

                                                                
                                                                    500
                                                                    xxx xxx
                                                                

                                                                
                                                                    501
                                                                    xxx xxx
                                                                
                                                            
                                                        
                                                    

                                                    
                                                        kwota

                                                        
                                                            
                                                        

                                                        PLN

                                                        
                                                            
                                                                
                                                                    Informacje o doładowaniu:

                                                                    
                                                                    Minimalna kwota
                                                                    doładowania
                                                                    to:

                                                                    
                                                                    zł

                                                                    
                                                                    Maksymalna
                                                                    kwota doładowania to:

                                                                    
                                                                    zł
                                                                
                                                            
                                                        
                                                    

                                                    
                                                        
                                                            

                                                            zapoznałem
                                                            się z

                                                            
                                                                regulaminem
                                                                doładowania on-line
                                                            

                                                            i akceptuję warunki
                                                        
                                                    

                                                    
                                                        
                                                            doładuj telefon
                                                        
                                                    
                                                
                                            
                                        

                                        
                                            
                                                manager finansowy

                                                
                                                    
                                                        wpływy
                                                        i wydatki za okres
                                                    

                                                    
                                                        ostatnie 3 miesiące
                                                            bieżący miesiąc

                                                            poprzedni miesiąc

                                                            ostatnie 3 miesiące

                                                            ostatnie 6 miesięcy

                                                            bieżący rok

                                                            poprzedni rok
                                                        
                                                    

                                                    -4 000 PLN-2 000 PLN0 PLN2 000 PLN4 000 PLN6 000 PLNShow all
                                                
                                            
                                        
                                    
                                
                            
                        

                        
                            
                                
                                    otwórz
                                        rachunek
                                

                                
                                    
                                    rachunki oszczędnościowe
                                

                                
                                    
                                        
                                            
                                                
                                                    TEStos

                                                    
                                                        (22 xxxx xxxx xxxx xxxx 0000 0000)
                                                    
                                                

                                                
                                                    
                                                        dostępne
                                                            środki

                                                        
                                                            dostępne
                                                                środki

                                                            
                                                                5 010

                                                                ,00

                                                                PLN
                                                            
                                                        
                                                    
                                                

                                                
                                                    wykonaj
                                                        przelew
                                                
                                            
                                        

                                        
                                            
                                                
                                                    typ
                                                        rachunku

                                                    Progress
                                                

                                                
                                                    oprocentowanie

                                                    2,5%
                                                
                                            

                                            
                                                historia
                                                    rachunku

                                                szczegóły
                                                    rachunku

                                                zamknij
                                                    rachunek
                                            
                                        
                                    
                                
                            

                            
                                
                                    załóż
                                        lokatę
                                

                                
                                    
                                    lokaty
                                

                                
                                    
                                        
                                            
                                                
                                                    lokata terminowa,

                                                    data zakończenia 01.01.2016
                                                
                                                
                                                    
                                                        kwota
                                                            lokaty
                                                        
                                                            kwota
                                                                lokaty
                                                            
                                                                31 020
                                                                ,20
                                                                PLN
                                                            
                                                        
                                                    
                                                
                                                
                                                    załóż
                                                        lokatę
                                                
                                            
                                        
                                        
                                            
                                                
                                                    typ
                                                        lokaty
                                                    dynamiczna
                                                
                                                
                                                    okres
                                                        lokaty
                                                    3 miesiące
                                                
                                                
                                                    oprocentowanie
                                                    3,95%
                                                
                                            
                                            
                                                historia lokaty
                                                szczegóły lokaty
                                            
                                        
                                    
                                
                            
                            
                                
                                    jak otrzymać
                                        kartę
                                
                                
                                    karty debetowe
                                
                                
                                    
                                        
                                            
                                                
                                                    VISA Electron
                                                
                                                Jan
                                                    Demobankowy
                                                
                                                    zastrzeż
                                                        kartę
                                                
                                            
                                        
                                        
                                            
                                                
                                                    numer
                                                        karty

                                                    0000 xxxx
                                                        xxxx 1111
                                                

                                                
                                                    status
                                                        karty

                                                    aktywna
                                                

                                                
                                                    do
                                                        konta

                                                    
                                                        [KO] konto na życie [11 211,31 PLN] 0011...0022
                                                    
                                                
                                            

                                            
                                                historia karty

                                                szczegóły karty
                                            
                                        
                                    
                                
                            

                            
                                
                                    złóż
                                        wniosek
                                

                                
                                    
                                    karty kredytowe
                                

                                
                                    
                                        
                                            
                                                
                                                    Visa Gold Standard
                                                
                                                Jan Demobankowy
                                                
                                                    
                                                        dostępne
                                                            środki

                                                        
                                                            dostępne
                                                                środki
                                                            
                                                                3 370
                                                                ,00
                                                                PLN
                                                            
                                                        
                                                    
                                                

                                                
                                                    zastrzeż
                                                        kartę
                                                
                                            
                                        

                                        
                                            
                                                
                                                    numer
                                                        karty
                                                    0000 00xx
                                                        xxxx 0000
                                                
                                                
                                                    status
                                                        karty
                                                    aktywna
                                                
                                                
                                                    do
                                                        spłaty natychmiast
                                                    
                                                        
                                                            125

                                                            ,00

                                                            PLN
                                                        
                                                    
                                                

                                                
                                                    minimalna
                                                        kwota spłaty

                                                    
                                                        
                                                            25

                                                            ,00

                                                            PLN
                                                        
                                                    
                                                

                                                
                                                    w
                                                        tym zaległość

                                                    
                                                        
                                                            50

                                                            ,00

                                                            PLN
                                                        
                                                    
                                                

                                                
                                                    termin
                                                        płatności

                                                    21.09.2014
                                                
                                            

                                            
                                                historia karty

                                                szczegóły karty

                                                zestawienia
                                                    transakcji

                                                spłać kartę
                                            
                                        
                                    
                                
                            

                            
                                
                                    złóż
                                        wniosek
                                

                                
                                    
                                    kredyty
                                

                                
                                    
                                        
                                            
                                                
                                                    kredyt ratalny
                                                

                                                
                                                    
                                                        pozostało
                                                            do spłaty

                                                        
                                                            pozostało
                                                                do spłaty

                                                            
                                                                13 070

                                                                ,83

                                                                PLN
                                                            
                                                        
                                                    
                                                

                                                
                                                    harmonogram
                                                
                                            
                                        

                                        
                                            
                                                
                                                    data
                                                        najbliższej raty

                                                    28.04.2014
                                                

                                                
                                                    kwota
                                                        najbliższej raty

                                                    
                                                        
                                                            350

                                                            ,00

                                                            PLN
                                                        
                                                    
                                                

                                                
                                                    
                                                        rachunek do spłaty

                                                        
                                                            
                                                                na ten rachunek wpłacaj kwoty rat zgodnie z
                                                                harmonogramem
                                                            
                                                        
                                                    

                                                    
                                                        [KO] konto na życie [13 159,20 PLN] 4141...0000
                                                    
                                                
                                            

                                            
                                                szczegóły
                                                    kredytu
                                            
                                        
                                    

                                    
                                        
                                            
                                                
                                                    limit w koncie
                                                

                                                
                                                    
                                                        bieżące
                                                            zadłużenie

                                                        
                                                            bieżące
                                                                zadłużenie

                                                            
                                                                0

                                                                ,00

                                                                PLN
                                                            
                                                        
                                                    
                                                

                                                
                                                    szczegóły
                                                
                                            
                                        

                                        
                                            
                                                
                                                    minimalna
                                                        miesięczna wpłata

                                                    
                                                        
                                                            30

                                                            ,00

                                                            PLN
                                                        
                                                    
                                                

                                                
                                                    
                                                        rachunek do spłaty

                                                        
                                                            
                                                                na ten rachunek wpłacaj kwotę minimalnej miesięcznej
                                                                wpłaty
                                                            
                                                        
                                                    

                                                    
                                                        [KO] konto na życie [13 159,20 PLN] 4141...0000
                                                    
                                                

                                                
                                                    kwota
                                                        przyznanego limitu

                                                    
                                                        
                                                            10 000

                                                            ,00

                                                            PLN
                                                        
                                                    
                                                
                                            
                                        
                                    
                                
                            

                            
                                
                                    ubezpiecz
                                        się
                                

                                
                                    
                                    ubezpieczenia
                                

                                
                                    
                                        
                                            
                                                
                                                    Assistance
                                                

                                                
                                                    data końca
                                                        ubezpieczenia:

                                                    bezterminowo
                                                
                                            
                                        

                                        
                                            
                                                
                                                    opis
                                                        ubezpieczenia

                                                    ubezpieczenie
                                                        mieszkania
                                                

                                                
                                                    tow.
                                                        ubezpieczneiowe

                                                    Towarzystwo
                                                        Ubezpieczeniowe ABC S.A.
                                                    
                                                

                                                
                                                    ubezpieczony

                                                    Jan
                                                        Demobankowy
                                                

                                                
                                                    konto
                                                        powiązane

                                                    41 4170 0000
                                                        1111 5001 0000 0000
                                                
                                            

                                            
                                                szczegóły ubezpieczenia
                                            
                                        
                                    
                                
                            
                        
                    
                </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;js  no-ie8 no-ie9&quot;]/body[1]/section[@class=&quot;container&quot;]/div[@class=&quot;grid-wrapper&quot;]/div[@class=&quot;grid main-container&quot;]/div[@class=&quot;main-content dashboard&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div</value>
   </webElementXpaths>
</WebElementEntity>
