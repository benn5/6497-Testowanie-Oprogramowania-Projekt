<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Konto na ycie                         _81cbe2</name>
   <tag></tag>
   <elementGuidId>ef26d5fc-5a36-4c06-9551-b28902e80d77</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.account-name.table-grid-23</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='accounts_list']/article/div/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>account-name table-grid-23</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                Konto na życie

                                                

                                                (41 4100 1111 1111 1111 1111 0000)
                                            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;accounts_list&quot;)/article[@class=&quot;account-item&quot;]/div[@class=&quot;row account-details box-white table-alike&quot;]/div[@class=&quot;table-header&quot;]/span[@class=&quot;account-name table-grid-23&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='accounts_list']/article/div/div/span</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/span</value>
   </webElementXpaths>
</WebElementEntity>
