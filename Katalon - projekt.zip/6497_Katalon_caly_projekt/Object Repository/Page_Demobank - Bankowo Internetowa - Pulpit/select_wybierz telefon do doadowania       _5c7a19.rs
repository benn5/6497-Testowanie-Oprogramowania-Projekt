<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_wybierz telefon do doadowania       _5c7a19</name>
   <tag></tag>
   <elementGuidId>0ada53c5-831a-4c64-8691-65dfe03f26b0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='widget_1_topup_receiver']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'widget_1_topup_receiver' and (text() = '
                                                                
                                                                    wybierz telefon do doładowania
                                                                

                                                                
                                                                    500
                                                                    xxx xxx
                                                                

                                                                
                                                                    501
                                                                    xxx xxx
                                                                
                                                            ' or . = '
                                                                
                                                                    wybierz telefon do doładowania
                                                                

                                                                
                                                                    500
                                                                    xxx xxx
                                                                

                                                                
                                                                    501
                                                                    xxx xxx
                                                                
                                                            ')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#widget_1_topup_receiver</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-classes</name>
      <type>Main</type>
      <value>selector-mt-small selector-ms-small topup_receiver</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>widget_1_topup_receiver</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                                
                                                                    wybierz telefon do doładowania
                                                                

                                                                
                                                                    500
                                                                    xxx xxx
                                                                

                                                                
                                                                    501
                                                                    xxx xxx
                                                                
                                                            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;widget_1_topup_receiver&quot;)</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='widget_1_topup_receiver']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='uniform-widget_1_topup_receiver']/select</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='wybierz telefon do doładowania'])[1]/following::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='do'])[2]/following::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='kwota'])[2]/preceding::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PLN'])[9]/preceding::select[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/form/div/div/div/select</value>
   </webElementXpaths>
</WebElementEntity>
